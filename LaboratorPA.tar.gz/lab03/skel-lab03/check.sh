#!/usr/bin/env bash

NUM_TASKS=2
TASKS=( task-1 task-2 )
NUM_TESTS=( 11 9 )

TIMEOUT_CPP=1
TIMEOUT_JAVA=1

source ./tests/base_check.sh
