#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

const int kNmax = 100005;

class Task {
 public:
	void solve() {
		read_input();
		print_output(get_result());
	}

 private:
	int n;
	int m;
	vector<int> adj[kNmax];
	vector<int> adjt[kNmax];

	void read_input() {
		ifstream fin("in");
		fin >> n >> m;
		for (int i = 1, x, y; i <= m; i++) {
			fin >> x >> y;
			adj[x].push_back(y);
			adjt[y].push_back(x);
		}
		fin.close();
	}

	void CTC(int root, int & cost, vector<int> & zif, vector<int> & order, stack<int> & stc, vector<vector<int>> & solution, vector<bool> & isstc) {
        order[root] = cost;
        zif[root] = cost;
        cost++;
        isstc[root] = true;
        stc.push(root);

        for (int next : adj[root]) {
            if (!zif[next]) {
                CTC(next, cost, zif, order, stc, solution, isstc);
                order[root] = min(order[next], order[root]);
            } else if (isstc[next]) {
                order[root] = min(zif[next], order[root]);
            }
        }

        if (zif[root] == order[root]) {
            vector<int> crtSol;
            int x;

            do {
                x = stc.top();
                stc.pop();
                crtSol.emplace_back(x);
                isstc[x] = false;
            } while (root != x);

            solution.emplace_back(crtSol);
            //verificare
            printf("%zu\n", solution.size());
        }
    }

    vector<vector<int>> get_result() {
        vector<vector<int>> sol;
        vector<int> disc(n + 1), firstAccessible(n + 1);
        vector<bool> isInStack(n + 1);
        stack<int> s;
        int startTime = 1;

        for (int i = 1; i <= n; ++i) {
            if (!disc[i]) {
                CTC(i, startTime, disc, firstAccessible, s, sol, isInStack);
            }
        }

        return sol;
    }

	void print_output(vector<vector<int>> result) {
		ofstream fout("out");
		fout << result.size() << '\n';
		for (const auto& ctc : result) {
			for (int nod : ctc) {
				fout << nod << ' ';
			}
			fout << '\n';
		}
		fout.close();
	}
};

int main() {
	Task *task = new Task();
	task->solve();
	delete task;
	return 0;
}
