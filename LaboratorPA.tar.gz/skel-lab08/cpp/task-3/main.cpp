#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

const int kNmax = 100005;

class Task {
public:
    void solve() {
        read_input();
        print_output(get_result());
    }

private:
    int n;
    int m;
    vector<int> adj[kNmax];

    struct Edge {
        int x;
        int y;

        Edge(int _x, int _y): x(_x), y(_y) {}
    };

    void read_input() {
        ifstream fin("in");
        fin >> n >> m;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y;
            adj[x].push_back(y);
            adj[y].push_back(x);
        }
        fin.close();
    }

    int cost = 1;

    void conex(int v, vector<int> & order, vector<Edge> & sol, vector<int> & zif, int root) {
        zif[v] = order[v] = cost++;

        for (int nextNode : adj[v]) {
            if (!zif[nextNode]) {
                conex(nextNode, order, sol, zif, v);
                order[v] = min(order[nextNode], order[v]);

                if (order[nextNode] > zif[v]) {
                    //verificare
                    printf("%d %d\n", v, nextNode);
                    sol.emplace_back(v, nextNode);
                }
            } else if (nextNode != root) {
                order[v] = min(zif[nextNode], order[v]);
            }
        }
    }

    vector<Edge> get_result() {
        vector<Edge> solution;
        vector<int> zif(n + 1);
        vector<int> order(n + 1);

        for (int i = 1; i <= n; ++i) {
            if (!zif[i]) {
                conex(i, order, solution, zif, 0);
            }
        }

        return solution;
    }

    void print_output(vector<Edge> result) {
        ofstream fout("out");
        fout << result.size() << '\n';
        for (int i = 0; i < int(result.size()); i++) {
            fout << result[i].x << ' ' << result[i].y << '\n';
        }
        fout.close();
    }
};

int main() {
    Task *task = new Task();
    task->solve();
    delete task;
    return 0;
} 
