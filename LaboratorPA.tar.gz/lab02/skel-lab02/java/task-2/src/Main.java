import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    static class Task {
        public final static String INPUT_FILE = "in";
        public final static String OUTPUT_FILE = "out";

        int n, m;
        int[] dist;

        private void readInput() {
            try {
                Scanner sc = new Scanner(new File(INPUT_FILE));
                n = sc.nextInt();
                m = sc.nextInt();
                dist = new int[n];
                for (int i = 0; i < n; i++) {
                    dist[i] = sc.nextInt();
                }
                sc.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        private void writeOutput(int result) {
            try {
                PrintWriter pw = new PrintWriter(new File(OUTPUT_FILE));
                pw.printf("%d\n", result);
                pw.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        private int getResult() {
            // TODO: Aflati numarul minim de opriri necesare pentru
            // a ajunge la destinatie.
            int start = 0;
            int drumuri = 0;
            int distanta = 0;
            //n -= 1;
            //while(n >= 0) {
            for(int i = 0; i < n; i++) {
                if(dist[i] > m) {
                    drumuri = 0;
                    distanta = 0;
                    break;
                }
               /* if(dist[i] == m) {
                    drumuri += 1;
                    distanta = 0;
                }  */              
                if(distanta + dist[i] > m) {
                    drumuri += 1;
                    distanta = 0;
                    
                }
//                 if(distanta + dist[i] == m) {
//                     drumuri += 1;
//                     
//                 }
                distanta += dist[i];
                     System.out.println(drumuri + " " + i + " " + distanta);
            }
                            //System.out.println(drumuri);
            if(distanta <= m && distanta != 0)
                drumuri += 1;
            return drumuri;
        }

        public void solve() {
            readInput();
            writeOutput(getResult());
        }
    }

    public static void main(String[] args) {
        new Task().solve();
    }
}
