#!/usr/bin/env bash

NUM_TASKS=2
TASKS=( task-1 task-2 )
NUM_TESTS=( 10 10 )

TIMEOUT_CPP=1
TIMEOUT_JAVA=7

source ./tests/base_check.sh
