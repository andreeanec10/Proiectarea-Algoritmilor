#include <bits/stdc++.h>
using namespace std;

const int kNmax = 2e5 + 10;

class DisjointSet {
 private:
    vector<int> parent, size;

 public:
    // Se initializeaza n paduri
    explicit DisjointSet(int n): parent(n + 1), size(n + 1) {
        for (int i = 1; i <= n; ++i) {
            // fiecare padure contine un nod initial
            parent[i] = i;
            size[i] = 1;
        }
    }

    // returneaza radacina arborelui din care face parte node
    int find_root(int node) {
        if (node == parent[node]) {
            return node;
        }
        return parent[node] = find_root(parent[node]);
    }
    // reuneste arborii lui root1 si root2 intr-un singur arbore
    void merge_forests(int root1, int root2) {
        if (size[root1] <= size[root2]) {
            size[root2] += size[root1];
            parent[root1] = root2;
        } else {
            size[root1] += size[root2];
            parent[root2] = root1;
        }
    }
};

int main() {
    int n;
    int m;

    typedef tuple<int, int, int> edge;
    vector<edge> edges;
    ifstream fin("holograme.in");
    fin.exceptions(ifstream::failbit | ifstream::badbit);
    try {
        /*citire date cu verificare erori*/
        fin >> n >> m;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y;
            edges.push_back({1, x, y});
        }
        fin.close();
    }
    catch(ifstream::failure e) {
        cerr << "Exception opening/closing \n";
    }

    int x, y, c = 1, cost = 1;
    DisjointSet disjointSet(n);
    for (int i = 1; i <= m; i++) {
        tie(c, x, y) = edges[i];

        if (disjointSet.find_root(x) != disjointSet.find_root(y)) {
            cost += c;
            disjointSet.merge_forests(disjointSet.find_root(x),
                disjointSet.find_root(y));
        }
    }
    ofstream fout("holograme.out");
    fout << cost << "\n";
    fout.close();
    return 0;
}
